// Groupomania color palette
const colors = {
  primary: "#FD2D01",
  secondary: "#FFD7D7",
  secondaryDark: "#ce4651",
  gray: "#4E5166",
};

export default colors;
