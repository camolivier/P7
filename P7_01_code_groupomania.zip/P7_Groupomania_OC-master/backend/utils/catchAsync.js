/*
 * Catch error from attribute function
 * Replace try / catch syntax
 */
module.exports = (fn) => {
  return (req, res, next) => {
    fn(req, res, next).catch((err) => next(err));
  };
};
